import { useEffect, useState } from 'react';
import {
  Building,
  CircleCheck,
  Clock,
  FileText,
  GraduationCap,
  IdCard,
  Info,
  Sparkles,
  TriangleExclamationPoint,
  X,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { findUpcomingClass, formatCountdown } from '../scheduleUtils';
import type { NotificationItem, RequestItem, ScheduleItem, TabType, UserProfile } from '../types';

type DashboardViewProps = {
  user: UserProfile;
  schedule: ScheduleItem[];
  notifications: NotificationItem[];
  requests: RequestItem[];
  onNavigate: (tab: TabType) => void;
  onMarkNotificationRead: (id: string) => void;
};

const REQUEST_STATUS: Record<RequestItem['status'], string> = {
  Создано: 'bg-slate-100 text-slate-600 border-slate-200',
  'Проверка деканатом': 'bg-amber-50 text-amber-700 border-amber-200',
  'Подписано ЭЦП': 'bg-blue-50 text-blue-700 border-blue-200',
  Готово: 'bg-emerald-50 text-emerald-700 border-emerald-200',
};

const NOTIFICATION_STYLE: Record<NotificationItem['type'], { icon: LucideIcon; wrap: string }> = {
  info: { icon: Info, wrap: 'bg-blue-50 text-blue-700' },
  warning: { icon: TriangleExclamationPoint, wrap: 'bg-amber-50 text-amber-700' },
  success: { icon: CircleCheck, wrap: 'bg-emerald-50 text-emerald-700' },
};

const CLASS_TYPE: Record<ScheduleItem['type'], string> = {
  Лекция: 'bg-blue-50 text-blue-700 border-blue-200',
  Семинар: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Язык: 'bg-amber-50 text-amber-700 border-amber-200',
  Экзамен: 'bg-rose-50 text-rose-700 border-rose-200',
};

function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase();
}

function sameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export default function DashboardView({
  user,
  schedule,
  notifications,
  requests,
  onNavigate,
  onMarkNotificationRead,
}: DashboardViewProps) {
  const [now, setNow] = useState(() => new Date());
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [studakOpen, setStudakOpen] = useState(false);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const upcoming = findUpcomingClass(schedule, now);
  const unread = notifications.filter((item) => !item.isRead).length;
  const activeRequests = requests.filter((item) => item.status !== 'Готово');
  const live = upcoming ? now.getTime() >= upcoming.start.getTime() : false;
  const countdown = upcoming
    ? formatCountdown((live ? upcoming.end.getTime() : upcoming.start.getTime()) - now.getTime())
    : '';

  return (
    <div className="pb-24">
      <header className="bg-slate-900 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-b-3xl px-4 pb-6 pt-6 shadow-md">
        <p className="text-xs text-slate-300">Цифровой деканат МГИМО</p>
        <div className="mt-4 flex items-center gap-3">
          {avatarFailed ? (
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-sm font-semibold">
              {initials(user.name)}
            </div>
          ) : (
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="h-14 w-14 shrink-0 rounded-2xl object-cover ring-2 ring-white/15"
              onError={() => setAvatarFailed(true)}
            />
          )}
          <div className="min-w-0">
            <h1 className="font-semibold tracking-tight text-lg leading-tight">{user.name}</h1>
            <p className="mt-1 truncate text-xs text-slate-300">{user.faculty}</p>
            <span className="mt-2 inline-flex rounded-full border border-amber-500/20 bg-amber-500/10 px-2.5 py-0.5 text-xs font-medium text-amber-400">
              {user.course} курс · {user.group}
            </span>
          </div>
        </div>
      </header>

      <div className="space-y-4 px-4 py-4">
        <section className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-semibold tracking-tight text-slate-900">Ближайшая пара</h2>
            <Clock className="h-4 w-4 text-slate-400" aria-hidden="true" />
          </div>
          {upcoming ? (
            <div className="mt-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${CLASS_TYPE[upcoming.item.type]}`}>
                  {upcoming.item.type}
                </span>
                <span className="text-xs text-slate-500">
                  {sameDay(upcoming.start, now)
                    ? 'Сегодня'
                    : upcoming.start.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' })}
                  {' · '}
                  {upcoming.item.time}
                </span>
              </div>
              <p className="mt-2 font-semibold tracking-tight text-slate-900">{upcoming.item.subject}</p>
              <p className="mt-1 text-xs text-slate-500">{upcoming.item.professor}</p>
              <div className="mt-3 flex items-start gap-2 text-sm text-slate-600">
                <Building className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
                <span>
                  {upcoming.item.building}, ауд. {upcoming.item.room}
                </span>
              </div>
              <div className="mt-4 rounded-xl bg-slate-50 px-3 py-3">
                <p className="text-xs text-slate-500">{live ? 'Идёт сейчас · до конца' : 'До начала'}</p>
                <p className="mt-1 font-semibold tracking-tight text-2xl tabular-nums text-slate-900">{countdown}</p>
              </div>
            </div>
          ) : (
            <p className="mt-3 text-sm text-slate-500">На ближайшие дни пар в расписании нет.</p>
          )}
        </section>

        <section>
          <h2 className="font-semibold tracking-tight text-slate-900">Быстрые действия</h2>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onNavigate('requests')}
              className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center gap-3 text-left transition-all active:scale-[0.99]"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
                <FileText className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="text-sm font-medium text-slate-900">Заявки</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('ai')}
              className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center gap-3 text-left transition-all active:scale-[0.99]"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-amber-500/20 bg-amber-500/10 text-amber-500">
                <Sparkles className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="text-sm font-medium text-slate-900">ИИ-ассистент</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('grades')}
              className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center gap-3 text-left transition-all active:scale-[0.99]"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
                <GraduationCap className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="text-sm font-medium text-slate-900">Зачётка</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('profile')}
              className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center gap-3 text-left transition-all active:scale-[0.99]"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 text-amber-400">
                <IdCard className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="text-sm font-medium text-slate-900">Профиль</span>
            </button>
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between">
            <h2 className="font-semibold tracking-tight text-slate-900">Уведомления деканата</h2>
            {unread > 0 && (
              <span className="rounded-full border border-amber-200 bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-700">
                {unread} новых
              </span>
            )}
          </div>
          <div className="mt-3 space-y-2">
            {notifications.map((item) => {
              const style = NOTIFICATION_STYLE[item.type];
              const Icon = style.icon;
              return (
                <article
                  key={item.id}
                  className={`bg-white rounded-2xl p-4 shadow-sm border border-slate-100 ${item.isRead ? 'opacity-70' : ''}`}
                >
                  <div className="flex items-start gap-3">
                    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${style.wrap}`}>
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-semibold tracking-tight text-sm text-slate-900">{item.title}</h3>
                        <span className="shrink-0 text-xs text-slate-500">{item.date}</span>
                      </div>
                      <p className="mt-1 text-sm text-slate-600">{item.message}</p>
                      {item.isRead ? (
                        <p className="mt-2 text-xs text-slate-400">Прочитано</p>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onMarkNotificationRead(item.id)}
                          className="mt-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl px-3.5 py-2 text-sm transition-colors"
                        >
                          Отметить прочитанным
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </section>

        <section className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-semibold tracking-tight text-slate-900">Активные заявки</h2>
            <button
              type="button"
              onClick={() => onNavigate('requests')}
              className="text-xs font-medium text-blue-600"
            >
              Все
            </button>
          </div>
          {activeRequests.length === 0 ? (
            <p className="mt-3 text-sm text-slate-500">Сейчас нет заявок в работе.</p>
          ) : (
            <ul className="mt-3 space-y-3">
              {activeRequests.slice(0, 3).map((item) => (
                <li key={item.id} className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-slate-900">{item.title}</p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {item.category} · {item.createdAt}
                    </p>
                  </div>
                  <span className={`shrink-0 rounded-full border px-2.5 py-0.5 text-xs font-medium ${REQUEST_STATUS[item.status]}`}>
                    {item.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {studakOpen && (
        <div className="fixed inset-0 z-[60] flex justify-center">
          <div className="relative flex w-full max-w-md items-end">
            <button
              type="button"
              aria-label="Закрыть студенческий билет"
              className="absolute inset-0 bg-slate-900/60"
              onClick={() => setStudakOpen(false)}
            />
            <div
              role="dialog"
              aria-modal="true"
              aria-label="Цифровой студенческий билет"
              className="relative w-full px-4 pb-24"
            >
              <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-5 shadow-md">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[11px] font-medium tracking-[0.18em] text-amber-400">MGIMO</p>
                    <p className="mt-1 font-semibold tracking-tight">Студенческий билет</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setStudakOpen(false)}
                    className="rounded-full bg-white/10 p-1.5 text-white"
                    aria-label="Закрыть"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-5 flex gap-3">
                  {avatarFailed ? (
                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white/10 font-semibold">
                      {initials(user.name)}
                    </div>
                  ) : (
                    <img src={user.avatarUrl} alt="" className="h-16 w-16 shrink-0 rounded-2xl object-cover" />
                  )}
                  <div className="min-w-0">
                    <p className="font-semibold tracking-tight leading-snug">{user.name}</p>
                    <p className="mt-1 text-xs text-slate-300">{user.faculty}</p>
                    <p className="mt-2 text-xs text-amber-300">
                      {user.course} курс · {user.group} · № {user.studentId}
                    </p>
                  </div>
                </div>
                <div className="mt-5 grid grid-cols-5 gap-1.5" aria-hidden="true">
                  {user.studentId.split('').concat(user.group.split('')).slice(0, 15).map((symbol, index) => (
                    <span
                      key={`${symbol}-${index}`}
                      className={`h-3 rounded-sm ${(symbol.charCodeAt(0) + index) % 2 === 0 ? 'bg-white' : 'bg-white/15'}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
